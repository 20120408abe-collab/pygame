# Animal Block Remove

動物のブロックを消していくパズルゲームです（Python + pygame）。

## あそびかた

### ダウンロードして遊ぶ（いちばんかんたん）
1. このページの緑の「Code」ボタン →「Download ZIP」を押す
2. ダウンロードした ZIP を開く（ダブルクリック）
3. 中の **index.html** をダブルクリックする
4. ゲームの画面が出たら、画面を1回クリックしてから遊ぶ

- **インターネットにつながっている必要があります。**（遊ぶための部品をネットから読みこみます）
- 最初の読みこみには少し時間がかかります。
- ブラウザは **Google Chrome** がおすすめです。Safari で動かないときは、index.html を右クリック →「このアプリケーションで開く」→「Google Chrome」を選んでください。
- 音は、はじめてキーを押したあとから鳴ります。

### パソコン版（Python）で遊ぶ
1. Python を入れて、`pip install pygame` を打つ
2. `AnimalBlockRemove` フォルダの中で `python3 main.py` を打つ

## 操作
| キー | 動き |
|---|---|
| ← → | いどう |
| ↑ | かいてん |
| ↓ | はやく落とす |
| ↓↓（すばやく2回） | 一気に落とす |
| SPACE | ホールド |
| P | 一時停止 |
| ESC | タイトルへ |

## ファイル
- `index.html` : ブラウザ版（ゲームとフォントが全部この1つに入っています）
- `AnimalBlockRemove/main.py` : ゲーム本体（パソコン版・改造用）
- `AnimalBlockRemove/font.ttf` : 日本語フォント（Noto Sans CJK JP をもとにしたもの。SIL Open Font License 1.1）
- `AnimalBlockRemove/OFL.txt` : フォントのライセンス（index.html の中にも同じフォントが入っています）

## ブラウザ版（index.html）を作り直すとき
`AnimalBlockRemove` の1つ上のフォルダで次のように打ち、できた
`AnimalBlockRemove/build/web/animalblockremove.html` の名前を `index.html` に変えて、
このリポジトリの index.html と置きかえます。

```
python3 -m pip install --upgrade pygbag
python3 -m pygbag --build --html AnimalBlockRemove
```
（main.py の1行目は、このとき使うブラウザ版の設定です。消さないでください）
